import { useState, useRef, useEffect } from "react";

const MODEL = "claude-sonnet-4-20250514";

const SYSTEM = `Tu es l'Assistant IA de la Mission AAA — un programme pour aider les gens à créer leur Agence d'Agents IA (AAA) et atteindre 10 000€/mois.

TON RÔLE : Tu guides l'utilisateur étape par étape, comme un mentor expert, à travers un processus structuré pour :
1. Identifier sa niche la plus rentable
2. Définir son offre et ses prix (modèle : 2 500€/mois x 4 clients = 10 000€/mois)
3. Créer son plan d'action concret pour ses 30 premiers jours
4. L'aider à trouver ses premiers clients
5. Lui créer des scripts de vente et pitchs personnalisés

NICHES CIBLES (entreprises avec budget et besoin fort) :
- Salles de sport / coaches sportifs
- Cabinets médicaux (dentistes, kinés, podologues, ostéos)
- Agences immobilières / BTP / artisans
- Experts-comptables / avocats / notaires
- Restaurants / hôtels / e-commerce

CE QUE TU PEUX VENDRE COMME AGENTS IA :
- Agent service client 24h/24
- Agent de prise de rendez-vous automatique
- Agent de prospection et relance client
- Agent de création de contenu
- Agent de facturation et gestion administrative

MODÈLE ÉCONOMIQUE : Setup 500-1500€ + Abonnement 500-3000€/mois. Objectif : 4 clients x 2500€ = 10 000€/mois.

COMPORTEMENT : Sois DIRECT et CONCRET avec des chiffres réels. Sois MOTIVANT. Propose des PROCHAINES ÉTAPES claires. Réponds en français.`;

const ÉTAPES = [
  { id: 1, label: "Ma situation", icon: "👤" },
  { id: 2, label: "Ma niche", icon: "🎯" },
  { id: 3, label: "Mon offre", icon: "💼" },
  { id: 4, label: "Plan 30j", icon: "🗓️" },
  { id: 5, label: "Mes scripts", icon: "📝" },
];

const QUICK = [
  { icon: "🏃", label: "Démarrer le diagnostic", text: "Je veux démarrer. Pose-moi les questions pour trouver ma niche et mon plan d'action." },
  { icon: "💰", label: "Combien puis-je gagner ?", text: "Combien puis-je réellement gagner en vendant des agents IA ? Donne-moi des exemples concrets avec des chiffres." },
  { icon: "🎯", label: "Trouver ma niche", text: "Aide-moi à trouver la niche la plus rentable pour moi selon mon profil." },
  { icon: "📞", label: "Script de vente", text: "Donne-moi un script complet pour appeler un prospect et lui vendre un agent IA." },
  { icon: "🔍", label: "Trouver des clients", text: "Comment trouver mes 4 premiers clients prêts à payer 2500€/mois ? Plan d'action pour cette semaine." },
  { icon: "🤖", label: "Quel agent créer ?", text: "Quel type d'agent IA est le plus facile à créer ET le plus rentable à vendre pour débuter ?" },
];

function Avatar({ role }) {
  const style = {
    width: 34, height: 34, borderRadius: "50%", display: "flex",
    alignItems: "center", justifyContent: "center", fontSize: 15, flexShrink: 0,
  };
  if (role === "user") return <div style={{ ...style, background: "linear-gradient(135deg,#3b82f6,#6366f1)", color: "white", fontWeight: 700 }}>V</div>;
  return <div style={{ ...style, background: "linear-gradient(135deg,#f59e0b,#ef4444)" }}>🤖</div>;
}

function Msg({ role, text, chips, error, loading }) {
  const isUser = role === "user";
  return (
    <div style={{ display: "flex", gap: 10, flexDirection: isUser ? "row-reverse" : "row", alignItems: "flex-start" }}>
      <Avatar role={role} />
      <div style={{ display: "flex", flexDirection: "column", gap: 5, maxWidth: "82%", alignItems: isUser ? "flex-end" : "flex-start" }}>
        {chips && chips.length > 0 && (
          <div style={{ display: "flex", flexWrap: "wrap", gap: 4 }}>
            {chips.map((c, i) => <span key={i} style={{ padding: "2px 8px", borderRadius: 20, fontSize: 10, fontWeight: 600, background: "#d1fae5", border: "1px solid #6ee7b7", color: "#065f46" }}>{c}</span>)}
          </div>
        )}
        <div style={{
          padding: "11px 15px",
          borderRadius: isUser ? "18px 18px 4px 18px" : "18px 18px 18px 4px",
          fontSize: 14, lineHeight: 1.75, whiteSpace: "pre-wrap", wordBreak: "break-word",
          background: error ? "#fee2e2" : isUser ? "linear-gradient(135deg,#3b82f6,#6366f1)" : "white",
          border: error ? "1px solid #fca5a5" : isUser ? "none" : "1px solid #e5e7eb",
          color: error ? "#991b1b" : isUser ? "white" : "#1e293b",
          boxShadow: isUser ? "0 2px 10px rgba(99,102,241,.3)" : "0 1px 4px rgba(0,0,0,.07)",
        }}>
          {loading ? (
            <span style={{ display: "inline-flex", gap: 5, alignItems: "center" }}>
              {[0, 1, 2].map(i => <span key={i} style={{ width: 7, height: 7, borderRadius: "50%", background: "#94a3b8", display: "inline-block", animation: `blink 1.3s ease-in-out ${i * .22}s infinite` }} />)}
            </span>
          ) : text}
        </div>
      </div>
    </div>
  );
}

export default function MissionAAA() {
  const [msgs, setMsgs] = useState([]);
  const [hist, setHist] = useState([]);
  const [input, setInput] = useState("");
  const [busy, setBusy] = useState(false);
  const [etape, setEtape] = useState(1);
  const chatRef = useRef(null);
  const taRef = useRef(null);

  useEffect(() => { if (chatRef.current) chatRef.current.scrollTop = chatRef.current.scrollHeight; }, [msgs]);
  useEffect(() => { initAgent(); }, []);

  const callAPI = async (messages) => {
    const res = await fetch("/api/chat", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ model: MODEL, max_tokens: 2048, system: SYSTEM, messages }),
    });
    return res.json();
  };

  const initAgent = async () => {
    setBusy(true);
    try {
      const data = await callAPI([{ role: "user", content: "Commence la conversation. Présente-toi et pose les premières questions pour comprendre ma situation actuelle (job, revenus, disponibilité, objectifs)." }]);
      const text = (data.content || []).filter(b => b.type === "text").map(b => b.text).join("\n\n");
      setMsgs([{ role: "bot", text: text || "Bonjour ! Je suis votre assistant Mission AAA 🚀\n\nPar où voulez-vous commencer ?" }]);
      setHist([
        { role: "user", content: "Commence la conversation." },
        { role: "assistant", content: text || "Bonjour !" }
      ]);
    } catch (e) {
      setMsgs([{ role: "bot", text: "Bonjour ! Je suis votre assistant Mission AAA 🚀\n\nComment puis-je vous aider aujourd'hui ?" }]);
    }
    setBusy(false);
  };

  const send = async (txt) => {
    const msg = (txt || input).trim();
    if (!msg || busy) return;
    setInput(""); if (taRef.current) taRef.current.style.height = "auto";
    setBusy(true);
    setMsgs(prev => [...prev, { role: "user", text: msg }, { role: "bot", loading: true }]);
    const newHist = [...hist, { role: "user", content: msg }];
    try {
      const data = await callAPI(newHist);
      if (data.error) throw new Error(data.error.message);
      const text = (data.content || []).filter(b => b.type === "text").map(b => b.text).join("\n\n");
      setMsgs(prev => [...prev.slice(0, -1), { role: "bot", text: text || "..." }]);
      setHist([...newHist, { role: "assistant", content: text || "…" }]);
      if (text.toLowerCase().includes("niche") && etape < 2) setEtape(2);
      if ((text.toLowerCase().includes("offre") || text.toLowerCase().includes("prix")) && etape < 3) setEtape(3);
      if (text.toLowerCase().includes("30 jour") && etape < 4) setEtape(4);
      if (text.toLowerCase().includes("script") && etape < 5) setEtape(5);
    } catch (e) {
      setMsgs(prev => [...prev.slice(0, -1), { role: "bot", text: "Erreur : " + e.message, error: true }]);
    }
    setBusy(false);
  };

  return (
    <div style={{ display: "flex", flexDirection: "column", height: "100vh", fontFamily: "'Inter',system-ui,sans-serif", background: "#0f172a" }}>
      <style>{`
        @keyframes blink{0%,100%{opacity:.15}50%{opacity:1}}
        *{box-sizing:border-box;margin:0;padding:0}
        ::-webkit-scrollbar{width:4px}
        ::-webkit-scrollbar-thumb{background:#334155;border-radius:4px}
        .qbtn:hover{background:rgba(255,255,255,.12)!important;transform:translateY(-1px)}
        .qbtn{transition:all .15s}
        textarea:focus{outline:none}
        body{margin:0}
      `}</style>

      {/* Header */}
      <div style={{ background: "linear-gradient(135deg,#1e1b4b,#312e81)", padding: "14px 20px", flexShrink: 0, borderBottom: "1px solid rgba(255,255,255,.1)" }}>
        <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between" }}>
          <div style={{ display: "flex", alignItems: "center", gap: 10 }}>
            <div style={{ fontSize: 28 }}>🚀</div>
            <div>
              <div style={{ fontWeight: 800, fontSize: 16, color: "white" }}>
                Mission AAA
                <span style={{ fontSize: 10, fontWeight: 500, padding: "2px 8px", borderRadius: 20, background: "rgba(251,191,36,.2)", color: "#fbbf24", border: "1px solid rgba(251,191,36,.3)", marginLeft: 8 }}>
                  {busy ? "⏳ En cours…" : "● Live"}
                </span>
              </div>
              <div style={{ fontSize: 11, color: "rgba(255,255,255,.6)", marginTop: 1 }}>Agence d'Agents IA · Objectif 10 000€/mois</div>
            </div>
          </div>
          <button onClick={() => { setMsgs([]); setHist([]); setEtape(1); initAgent(); }}
            style={{ fontSize: 12, padding: "5px 13px", borderRadius: 8, border: "1px solid rgba(255,255,255,.2)", background: "rgba(255,255,255,.1)", cursor: "pointer", color: "rgba(255,255,255,.8)", fontFamily: "inherit" }}>
            Réinit.
          </button>
        </div>
        {/* Progress */}
        <div style={{ display: "flex", gap: 4, marginTop: 14 }}>
          {ÉTAPES.map(e => (
            <div key={e.id} style={{ flex: 1, display: "flex", flexDirection: "column", alignItems: "center", gap: 4 }}>
              <div style={{ width: "100%", height: 3, borderRadius: 2, background: e.id <= etape ? "linear-gradient(90deg,#f59e0b,#ef4444)" : "rgba(255,255,255,.15)", transition: "background .4s" }} />
              <div style={{ fontSize: 9, color: e.id <= etape ? "#fbbf24" : "rgba(255,255,255,.35)", fontWeight: e.id === etape ? 700 : 400 }}>{e.icon} {e.label}</div>
            </div>
          ))}
        </div>
      </div>

      {/* Chat */}
      <div ref={chatRef} style={{ flex: 1, overflowY: "auto", padding: "18px 16px", display: "flex", flexDirection: "column", gap: 16 }}>
        {msgs.map((m, i) => <Msg key={i} role={m.role || "bot"} text={m.text} chips={m.chips} error={m.error} loading={m.loading} />)}
        {!busy && msgs.length <= 2 && (
          <div style={{ marginTop: 4 }}>
            <div style={{ fontSize: 11, color: "rgba(255,255,255,.4)", marginBottom: 10, fontWeight: 500 }}>OU CHOISISSEZ UN SUJET :</div>
            <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 7 }}>
              {QUICK.map((q, i) => (
                <button key={i} className="qbtn" onClick={() => send(q.text)} style={{ padding: "10px 12px", borderRadius: 10, border: "1px solid rgba(255,255,255,.1)", background: "rgba(255,255,255,.07)", cursor: "pointer", textAlign: "left", fontSize: 12, color: "rgba(255,255,255,.85)", fontFamily: "inherit", display: "flex", alignItems: "center", gap: 7 }}>
                  <span style={{ fontSize: 16 }}>{q.icon}</span>
                  <span style={{ fontWeight: 500, lineHeight: 1.4 }}>{q.label}</span>
                </button>
              ))}
            </div>
          </div>
        )}
      </div>

      {/* Stats */}
      <div style={{ display: "flex", justifyContent: "space-around", padding: "8px 16px", background: "rgba(255,255,255,.04)", borderTop: "1px solid rgba(255,255,255,.08)", flexShrink: 0 }}>
        {[{ label: "Objectif mensuel", val: "10 000€" }, { label: "Clients nécessaires", val: "4 clients" }, { label: "Prix par client", val: "2 500€/mois" }, { label: "Marché", val: "10M d'entreprises" }].map((s, i) => (
          <div key={i} style={{ textAlign: "center" }}>
            <div style={{ fontSize: 13, fontWeight: 700, color: "#fbbf24" }}>{s.val}</div>
            <div style={{ fontSize: 9, color: "rgba(255,255,255,.4)", marginTop: 1 }}>{s.label}</div>
          </div>
        ))}
      </div>

      {/* Input */}
      <div style={{ padding: "12px 16px", background: "#1e293b", borderTop: "1px solid rgba(255,255,255,.08)", flexShrink: 0 }}>
        <div style={{ display: "flex", gap: 8, alignItems: "flex-end" }}>
          <textarea ref={taRef} value={input}
            onChange={e => { setInput(e.target.value); e.target.style.height = "auto"; e.target.style.height = Math.min(e.target.scrollHeight, 110) + "px"; }}
            onKeyDown={e => { if (e.key === "Enter" && !e.shiftKey) { e.preventDefault(); send(); } }}
            placeholder="Répondez ou posez une question… (Entrée pour envoyer)"
            rows={1}
            style={{ flex: 1, padding: "10px 13px", border: "1.5px solid rgba(255,255,255,.1)", borderRadius: 12, fontSize: 13.5, fontFamily: "inherit", resize: "none", minHeight: 42, maxHeight: 110, background: "rgba(255,255,255,.05)", color: "white", lineHeight: 1.55, transition: "border-color .15s" }}
            onFocus={e => e.target.style.borderColor = "rgba(251,191,36,.5)"}
            onBlur={e => e.target.style.borderColor = "rgba(255,255,255,.1)"}
          />
          <button onClick={() => send()} disabled={busy || !input.trim()}
            style={{ height: 42, padding: "0 18px", borderRadius: 12, border: "none", background: (busy || !input.trim()) ? "rgba(255,255,255,.1)" : "linear-gradient(135deg,#f59e0b,#ef4444)", color: (busy || !input.trim()) ? "rgba(255,255,255,.3)" : "white", fontWeight: 700, fontSize: 14, cursor: busy ? "not-allowed" : "pointer", flexShrink: 0, whiteSpace: "nowrap" }}>
            {busy ? "…" : "Envoyer ↑"}
          </button>
        </div>
      </div>
    </div>
  );
}
